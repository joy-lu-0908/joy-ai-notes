import { defineConfig } from 'vitepress'

export default defineConfig({
  title: "Joy's AI Notes",
  description: 'AI 算法、LLM、推荐系统、科研与面试手撕笔记',
  lang: 'zh-CN',
  base: process.env.VITEPRESS_BASE || '/',
  cleanUrls: true,
  lastUpdated: true,
  themeConfig: {
    nav: [
      { text: '首页', link: '/' },
      { text: '算法手撕', link: '/algorithm/' },
      { text: 'LLM', link: '/llm/' },
      { text: '推荐系统', link: '/recommendation/' },
      { text: '项目', link: '/projects/' },
      { text: '面试', link: '/interview/' }
    ],
    sidebar: {
      '/algorithm/': [
        {
          text: 'Algorithm Practice',
          items: [
            { text: '题库首页', link: '/algorithm/' },
            { text: '1. Two Sum', link: '/algorithm/problems/two-sum' },
            { text: '3. 无重复字符的最长子串', link: '/algorithm/problems/longest-substring' },
            { text: '146. LRU Cache', link: '/algorithm/problems/lru-cache' },
            { text: '215. 数组中的第 K 个最大元素', link: '/algorithm/problems/quickselect' },
            { text: '25. K 个一组翻转链表', link: '/algorithm/problems/reverse-k-group' }
          ]
        }
      ],
      '/llm/': [
        { text: 'LLM', items: [{ text: '总览', link: '/llm/' }, { text: 'Multi-Head Attention', link: '/llm/mha' }] }
      ],
      '/recommendation/': [
        { text: 'Recommendation', items: [{ text: '总览', link: '/recommendation/' }, { text: 'Semantic ID', link: '/recommendation/semantic-id' }] }
      ],
      '/projects/': [
        { text: 'Projects', items: [{ text: '总览', link: '/projects/' }, { text: 'Generative Recommender', link: '/projects/generative-recommender' }] }
      ]
    },
    search: { provider: 'local' },
    outline: { level: [2, 3], label: '本页目录' },
    docFooter: { prev: '上一篇', next: '下一篇' },
    lastUpdated: { text: '最后更新' },
    footer: { message: 'Built with VitePress', copyright: 'Joy\'s AI Notes' }
  },
  markdown: {
    lineNumbers: true,
    math: true
  }
})
